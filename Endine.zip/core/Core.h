
namespace Core
{
    struct Vector2
    {
        int X,Y;

        Vector2()
            : X(0), Y(0)
        {}
        Vector2(int x, int y)
                : X(x), Y(y)
        {}
    };

}