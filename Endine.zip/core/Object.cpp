#include "Object.h"
#include "Core.h"

namespace Core
{
//    void Object::Move(const Vector2& toPoint)
//    {
//        Position.X = toPoint.X;
//        Position.Y = toPoint.Y;
//    }

}